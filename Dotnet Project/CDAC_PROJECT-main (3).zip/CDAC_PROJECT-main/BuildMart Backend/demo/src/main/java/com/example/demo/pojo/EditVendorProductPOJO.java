package com.example.demo.pojo;

public class EditVendorProductPOJO {

}
