export default function LoginSuccess() {
  return <h1>Login Successfull</h1>;
}
