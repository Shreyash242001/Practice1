export default function EditSuccess(){

    const user = JSON.parse(localStorage.getItem("loggedUser"));
    return(
        <div className="fs-4">
            <h2>Profile edited successfully</h2>
            
            
        </div>
    )
}