package com.demo.service;

import com.demo.beans.Bookings;

public interface VenueService {

	void addNewVenue(Bookings b);

}
