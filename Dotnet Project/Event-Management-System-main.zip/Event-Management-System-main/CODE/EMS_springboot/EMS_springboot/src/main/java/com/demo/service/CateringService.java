package com.demo.service;

import com.demo.beans.Bookings;

public interface CateringService {

	void addNewCatering (Bookings b);

}
