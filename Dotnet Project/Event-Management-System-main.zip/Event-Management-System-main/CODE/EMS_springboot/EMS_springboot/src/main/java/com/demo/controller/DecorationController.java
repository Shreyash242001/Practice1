package com.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.beans.Bookings;
import com.demo.service.DecorationService;

//@RestController
//@RequestMapping("/bookings")

public class DecorationController {
//	@Autowired
//	DecorationService decorationService;

//	@PostMapping("/")
//	public ResponseEntity<String> addNewDecoration(@RequestBody Bookings b) {
//		System.out.println(b);
//		decorationService.addNewDecoration(b);
//		return ResponseEntity.ok("added successfully");
//	}
}
