package com.demo.service;

import com.demo.beans.Bookings;

public interface MediaService {

	void addNewMedia(Bookings b);

}
