package com.demo.service;

import com.demo.beans.Bookings;

public interface DecorationService {

	void addNewDecoration(Bookings b);

}
